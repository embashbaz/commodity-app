package com.example.bazibuhebashige.notetakerapp;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class DataManagerTest {
    @Before
   public void setuptest() throws Exception{
        DataManager dm = DataManager.getInstance();
        dm.getNotes().clear();
        dm.initializeExampleNotes();

    }
    @Test
    public void createNewNote() {
        DataManager dataManager = DataManager.getInstance();
        final CourseInfo note = dataManager.getCourse("android async");
        final String noteTitle = "this is the note title";
        final String noteText = "this is the note text";

        int noteIndex = dataManager.createNewNote();
        NoteInfo newNote = dataManager.getNotes().get(noteIndex);
        newNote.setCourse(note);
        newNote.setTitle(noteTitle);
        newNote.setText(noteText);



        NoteInfo compareNote = dataManager.getNotes().get(noteIndex);
        assertEquals(compareNote.getCourse(), note);
        assertEquals(compareNote.getTitle(), noteTitle);
        assertEquals(compareNote.getText(), noteText);


    }


    @Test
    public void findsimilarnote() throws Exception{
        DataManager dataManager = DataManager.getInstance();
        final CourseInfo note = dataManager.getCourse("android async");
        final String noteTitle = "this is the note title";
        final String noteText1 = "this is the note text";
        final String noteText2 = "this is the note 22 text";


        int noteIndex1 = dataManager.createNewNote();
        NoteInfo newNote1 = dataManager.getNotes().get(noteIndex1);
        newNote1.setCourse(note);
        newNote1.setTitle(noteTitle);
        newNote1.setText(noteText1);

        int noteIndex2 = dataManager.createNewNote();
        NoteInfo newNote2 = dataManager.getNotes().get(noteIndex2);
        newNote2.setCourse(note);
        newNote2.setTitle(noteTitle);
        newNote2.setText(noteText2);

        int findnoteindex1 = dataManager.findNote(newNote1);
        assertEquals( noteIndex1, findnoteindex1);


        int findnoteindex2 = dataManager.findNote(newNote2);
        assertEquals(findnoteindex2, noteIndex2);







    }
}