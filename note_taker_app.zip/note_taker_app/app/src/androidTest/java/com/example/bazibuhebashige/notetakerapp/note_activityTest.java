package com.example.bazibuhebashige.notetakerapp;

import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class note_activityTest {
@Rule
    ActivityTestRule<note_activity> mNoteactivity = new ActivityTestRule<>(note_activity.class);
@Test
    public void createNewNote(){


}

}