package com.example.bazibuhebashige.notetakerapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class CourseRecycleViewAdapter extends RecyclerView.Adapter<CourseRecycleViewAdapter.ViewHolder> {


    private final Context mContext;
    private final List<CourseInfo> mCourse;
    private final LayoutInflater layoutInflater;

    public CourseRecycleViewAdapter(Context mContext, List<CourseInfo> mCourse) {
        this.mContext = mContext;
        layoutInflater = LayoutInflater.from(mContext);
        this.mCourse = mCourse;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemview = layoutInflater.inflate(R.layout.individual_course, viewGroup, false);

        return new ViewHolder(itemview);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        CourseInfo course = mCourse.get(i);
        viewHolder.textcourse.setText(course.getTitle());

        viewHolder.curentposition = i;

    }

    @Override
    public int getItemCount() {
        return mCourse.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public final TextView textcourse;

        public int curentposition;

        public ViewHolder(View itemview)
        {
            super(itemview);
            textcourse = itemview.findViewById(R.id.textcourse);


            itemview.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Snackbar.make(v,mCourse.get(curentposition).getTitle(), Snackbar.LENGTH_LONG).show();
                }
            });

        }


    }
}
