package com.example.bazibuhebashige.notetakerapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import java.util.List;

public class listitem extends AppCompatActivity {

    private NoteRecycleViewAdapter noteRecyclerAdapter;

    //private ArrayAdapter<NoteInfo> adapternote;
@Override
protected void onResume(){
    super.onResume();

    noteRecyclerAdapter.notifyDataSetChanged();

    //adapternote.notifyDataSetChanged();

}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listitem);

        initializedDosplayContent();

        /**
        final ListView listview = findViewById(R.id.list_note);

        List<NoteInfo> mynote = DataManager.getInstance().getNotes();

       // adapternote = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1 , mynote);

        //listview.setAdapter(adapternote);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {


                Intent intent = new Intent(listitem.this, note_activity.class);
                    NoteInfo note = (NoteInfo) listview.getItemAtPosition(position);
                    intent.putExtra(note_activity.NOTE_INFO, position);
                startActivity(intent);


            }
        });
**/
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.new_item) {
            Intent startnewactivity= new Intent(this, note_activity.class);
            startActivity(startnewactivity);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private void initializedDosplayContent(){

    final RecyclerView recyclerView = findViewById(R.id.list_note);
    final LinearLayoutManager mLinearlayouymanager = new LinearLayoutManager(this);
      recyclerView.setLayoutManager(mLinearlayouymanager);
        List<NoteInfo> notes = DataManager.getInstance().getNotes();
        noteRecyclerAdapter = new NoteRecycleViewAdapter(this, notes);
        recyclerView.setAdapter(noteRecyclerAdapter);


    }
}
