package com.example.bazibuhebashige.notetakerapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.List;

public class note_activity extends AppCompatActivity {



    final public static String NOTE_INFO = "NOTE_INFO";
    public static final String NOTE_TITLE = "NOTE_TITLE";
    public static final String NOTE_TEXE = "NOTE_TEXT";
    public static final String COURSE_ID = "COURSE_ID";

    NoteInfo mnote;
    boolean misnewnote;
    private EditText texttitle;
    private EditText texttext;
    private Spinner spinner_courses;
    public int noteposition;
    private boolean deleteistrue;
    private String moriginalcourseid;
    private String originaltitleid;
    private String originaltext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_activity);

        //setting up the spinner that cotain the courses

        spinner_courses = findViewById(R.id.spinner_course);

        List<CourseInfo> course= DataManager.getInstance().getCourses();

        ArrayAdapter<CourseInfo> adaptercourses = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, course);
        adaptercourses.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_courses.setAdapter(adaptercourses);

        texttitle = findViewById(R.id.edittext_title);
        texttext = findViewById(R.id.editText_note);

        //getvalues from the data manager
        displayvalues();
        if(savedInstanceState==null) {
            saveoriginaldata();
        }
        else{
            restoreoriginalvalues(savedInstanceState);
            
        }
        if(!misnewnote) {
            //display values in our activity
            displaynote(spinner_courses, texttitle, texttext);
        }
    }
   //getting original data from assigning them to our activity
    private void restoreoriginalvalues(Bundle savedInstanceState) {
        moriginalcourseid = savedInstanceState.getString(COURSE_ID);
        originaltext = savedInstanceState.getString(NOTE_TEXE);
        originaltitleid = savedInstanceState.getString(NOTE_TITLE);

    }


    //saving original values incase the user change value and want to go back the prevouis values
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(COURSE_ID, moriginalcourseid);
        outState.putString(NOTE_TITLE, originaltitleid);
        outState.putString(NOTE_TEXE, originaltext);
    }

    private void saveoriginaldata() {
        moriginalcourseid = mnote.getCourse().getCourseId();
        originaltitleid = mnote.getTitle();
        originaltext = mnote.getText();

    }

    private void displaynote(Spinner spinner_courses, EditText texttitle, EditText texttext) {

        List<CourseInfo>courses = DataManager.getInstance().getCourses();
        int courseindex = courses.indexOf(mnote.getCourse());
        spinner_courses.setSelection(courseindex);
        texttitle.setText(mnote.getTitle());
        texttext.setText(mnote.getText());


    }

    private void displayvalues() {
        Intent intent = getIntent();
        int indexpassed = intent.getIntExtra(NOTE_INFO, -1);

        misnewnote = indexpassed == -1;
        if(misnewnote){
            createnewnote();
        }
        else {
            mnote = DataManager.getInstance().getNotes().get(indexpassed);
        }
    }
    //create a new note
    private void createnewnote() {

        DataManager dm =  DataManager.getInstance();
        noteposition = dm.createNewNote();

        mnote = dm.getNotes().get(noteposition);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.send_email) {
                emailbody();
            return true;
        }
        else if (id== R.id.ignore)
        {
            deleteistrue = true;
            finish();
        }
        else if (id == R.id.action_next) {
            moveNext();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem item = menu.findItem(R.id.action_next);
        int lastItem = DataManager.getInstance().getNotes().size()-1;
        item.setEnabled(noteposition<lastItem);


        return super.onPrepareOptionsMenu(menu);

    }

    private void moveNext() {
        Savenote();
        ++noteposition;
        mnote = DataManager.getInstance().getNotes().get(noteposition);
        saveoriginaldata();
        displaynote(spinner_courses, texttitle, texttext );

        invalidateOptionsMenu();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(deleteistrue){
            if(misnewnote){
                DataManager.getInstance().removeNote(noteposition);
            }
            else{
                setoriginalcontent();
            }
        }else {
            Savenote();
        }

    }
    //set original values if the user want to leave the activity without leaving our app
    private void setoriginalcontent() {
        CourseInfo course = DataManager.getInstance().getCourse(moriginalcourseid);
        mnote.setCourse(course);
        mnote.setTitle(originaltitleid);
        mnote.setText(originaltext);
    }
    //save new values
    private void Savenote() {
        mnote.setCourse((CourseInfo) spinner_courses.getSelectedItem());
        mnote.setText(texttext.getText().toString());
        mnote.setTitle(texttitle.getText().toString());

    }
        //implicit intent to open and send a mail
    public void emailbody (){
        CourseInfo courses = (CourseInfo) spinner_courses.getSelectedItem();
        String subject = texttitle.getText().toString();
        String text = "check what i found on pluralsight on" + subject + "\n" + texttext.getText().toString();

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("message/rfc2822");
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, text);

        startActivity(intent);

    }
}
